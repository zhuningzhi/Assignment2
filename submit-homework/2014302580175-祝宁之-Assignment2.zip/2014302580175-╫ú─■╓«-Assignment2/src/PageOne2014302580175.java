import java.awt.BorderLayout;
import java.awt.FlowLayout;


import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;

import javax.swing.JTextPane;

public class PageOne2014302580175 extends JDialog {

	private final JPanel contentPanel = new JPanel();

	/**
	 * Launch the application.
	 */

	/**
	 * Create the dialog.
	 */
	public PageOne2014302580175() {
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		Operate2014302580175 one =new Operate2014302580175();
		String a=one.getemail();
		String b=one.getphone();

		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(38, 64, 318, 55);
		textArea.append("��ʦ����"+a+"��ʦ�绰"+b);
		
		contentPanel.add(textArea);
		
		JTextPane txtpntext = new JTextPane();
		txtpntext.setText("\u8C22\u8C22,\u5DF2\u5C06\u4E0A\u65B9\u4FE1\u606F\u751F\u6210text\u6587\u4EF6\u4E8E\u76EE\u5F55");
		txtpntext.setBounds(85, 146, 216, 48);
		contentPanel.add(txtpntext);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
		}
	}
}
