import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;



import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.awt.event.ActionEvent;
import javax.swing.JTextPane;
import java.awt.Font;
import java.awt.Color;

public class MainPage2014302580175 extends JDialog {

	private final JPanel contentPanel = new JPanel();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			MainPage2014302580175 dialog = new MainPage2014302580175();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public MainPage2014302580175() {
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JButton button = new JButton("\u5F00\u59CB\u722C\u53D6\u8001\u5E08\u624B\u673A\u4E0E\u90AE\u7BB1");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
//�õģ���β�����ص㣬���ǻ���������һ����
				Operate2014302580175 one =new Operate2014302580175();
				String a=one.getemail();
				String b=one.getphone();
				try {
					FileOutputStream out=new FileOutputStream("assignment2.text");
					try {
						out.write((a + "\n").getBytes());
						out.write((b + "\n").getBytes());
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					try {
						out.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
//�뵯�����ڶ���������
				PageOne2014302580175 dialog = new PageOne2014302580175();
				dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
				dialog.setVisible(true);

			
			}
		});
		button.setBounds(125, 101, 180, 67);
		contentPanel.add(button);
		{
			JTextPane textPane = new JTextPane();
			textPane.setForeground(Color.BLUE);
			textPane.setFont(new Font("����", Font.PLAIN, 20));
			textPane.setText("\u5B9E\u9A8C\u8BFE\u7B2C\u4E8C\u6B21\u4F5C\u4E1A");
			textPane.setBounds(125, 35, 180, 41);
			contentPanel.add(textPane);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
		}
	}
}
